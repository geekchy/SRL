Action()
{

/*	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_auto_header("DNT", 
		"1");       */
lr_start_transaction("openhome");

	web_url("kalimanjaro.hpeswlab.net", 
		"URL=https://kalimanjaro.hpeswlab.net/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
lr_end_transaction("openhome", LR_AUTO);
	
		
/*
	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=F3796861C1C442DAB051D683EE1ACFFD&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180813; DOMAIN=iecvlist.microsoft.com");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1479242656000/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
*/

lr_start_transaction("openwebtour");

	web_url("WebTours", 
		"URL=https://kalimanjaro.hpeswlab.net/WebTours", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://kalimanjaro.hpeswlab.net/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
lr_end_transaction("openwebtour", LR_AUTO);

	lr_think_time(15);
	
lr_start_transaction("login");

	web_submit_form("login.pl", 
		"Snapshot=t4.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=61", ENDITEM, 
		"Name=login.y", "Value=5", ENDITEM, 
		LAST);
lr_end_transaction("login", LR_AUTO);

lr_start_transaction("logoff");

	web_image("SignOff Button", 
		"Alt=SignOff Button", 
		"Snapshot=t5.inf", 
		LAST);
lr_end_transaction("logoff", LR_AUTO);

	return 0;
}